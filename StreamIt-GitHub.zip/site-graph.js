// Anonymous architecture only: no source names, domains or runtime URLs.
'use strict';
const groups = {
  core: {name: 'Nucleo', color: '#76ead5'},
  content: {name: 'Contenuti', color: '#7aa8ff'},
  playback: {name: 'Riproduzione', color: '#ff8fa3'},
  tv: {name: 'TV', color: '#e7c990'},
  system: {name: 'Sistema', color: '#b39cff'}
};
const roles = [
  ['Interfaccia', 'core'], ['Catalogo film', 'content'], ['Catalogo serie', 'content'], ['Ricerca', 'content'],
  ['Immagini e metadati', 'content'], ['Riproduzione video', 'playback'], ['Sezione TV', 'tv'], ['Guida programmi', 'tv'],
  ['Lista principale', 'tv'], ['Lista alternativa', 'tv'], ['Motore TV', 'tv'], ['Aggiornamenti', 'system'],
  ['Pubblicazione', 'system'], ['Preferiti locali', 'tv'], ['Gestione audio', 'playback']
];
const edges = [[0,1],[0,2],[0,3],[0,5],[0,6],[0,11],[1,4],[2,4],[3,4],[1,5],[2,5],[3,5],[6,7],[6,8],[6,9],[6,10],[6,13],[8,10],[11,12],[5,14],[0,14]];
const W = 900, H = 520, CX = W / 2, CY = H / 2;
// Each area gravitates around its own anchor so clusters stay readable.
const anchors = {core: [CX - 10, CY - 15], content: [CX - 270, CY - 105], playback: [CX + 270, CY - 120], tv: [CX + 185, CY + 115], system: [CX - 280, CY + 120]};
const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
const degree = roles.map((_, i) => edges.filter(edge => edge.includes(i)).length);
const nodes = roles.map(([role, group], i) => ({role, group, label: `•••• ${String(i + 1).padStart(2, '0')}`, r: i ? 7 + degree[i] * 1.6 : 20}));
const ns = 'http://www.w3.org/2000/svg';
const svg = document.getElementById('graph'), scene = document.getElementById('scene'), detail = document.getElementById('detail');
function element(tag, attrs, parent) { const el = document.createElementNS(ns, tag); Object.entries(attrs).forEach(([key, value]) => el.setAttribute(key, value)); parent.appendChild(el); return el; }

let selected = -1, filter = null, view = {x: 0, y: 0, k: 1}, drag = null, pan = null, heat = 1;

function placeNodes() {
  nodes.forEach((node, i) => {
    const [ax, ay] = anchors[node.group], angle = i * 2.399;
    Object.assign(node, {x: ax + Math.cos(angle) * 40, y: ay + Math.sin(angle) * 40, vx: 0, vy: 0});
  });
  heat = 1;
}

const defs = svg.querySelector('defs');
const edgeEls = edges.map(([a, b], i) => {
  const gradient = element('linearGradient', {id: `edge-${i}`, gradientUnits: 'userSpaceOnUse'}, defs);
  element('stop', {offset: '0', 'stop-color': groups[nodes[a].group].color}, gradient);
  element('stop', {offset: '1', 'stop-color': groups[nodes[b].group].color}, gradient);
  return {path: element('path', {class: 'edge', stroke: `url(#edge-${i})`}, document.getElementById('edges')), gradient};
});
const sparks = edges.map(([a]) => element('circle', {class: 'spark', r: 2.4, fill: groups[nodes[a].group].color, filter: 'url(#glow)'}, document.getElementById('sparks')));

const nodeEls = nodes.map((node, i) => {
  const color = groups[node.group].color;
  const g = element('g', {class: i ? 'node' : 'node hub', tabindex: '0', role: 'button', 'aria-label': `Nodo anonimo ${i + 1}: ${node.role}`, 'aria-pressed': 'false'}, document.getElementById('nodes'));
  element('circle', {class: 'halo', r: node.r + 10, fill: color}, g);
  element('circle', {class: 'core', r: node.r, stroke: color, filter: 'url(#glow)'}, g);
  element('circle', {class: 'dot', r: Math.max(3, node.r * .38), fill: color}, g);
  element('text', {class: 'code', y: node.r + 16, 'text-anchor': 'middle'}, g).textContent = node.label;
  element('text', {class: 'role', y: node.r + 29, 'text-anchor': 'middle'}, g).textContent = node.role;
  g.addEventListener('click', () => { if (!g.dataset.moved) select(i === selected ? -1 : i); delete g.dataset.moved; });
  g.addEventListener('keydown', event => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); select(i === selected ? -1 : i); } });
  g.addEventListener('pointerdown', event => { event.stopPropagation(); drag = {i, x: event.clientX, y: event.clientY}; g.setPointerCapture(event.pointerId); });
  g.addEventListener('pointermove', event => {
    if (!drag || drag.i !== i) return;
    if (Math.hypot(event.clientX - drag.x, event.clientY - drag.y) > 4) g.dataset.moved = '1';
    const point = toScene(event);
    node.x = point.x; node.y = point.y; node.vx = node.vy = 0; heat = Math.max(heat, .4);
    if (reduceMotion) render();
  });
  const release = () => { drag = null; };
  g.addEventListener('pointerup', release); g.addEventListener('pointercancel', release);
  return g;
});

function toScene(event) { return new DOMPoint(event.clientX, event.clientY).matrixTransform(scene.getScreenCTM().inverse()); }

// Small force layout: repulsion, springs along edges, pull toward the area anchor.
function tick() {
  const alpha = .06 * heat;
  for (let i = 0; i < nodes.length; i++) {
    for (let j = i + 1; j < nodes.length; j++) {
      const a = nodes[i], b = nodes[j]; let dx = b.x - a.x, dy = b.y - a.y, d2 = dx * dx + dy * dy || 1;
      const d = Math.sqrt(d2), min = a.r + b.r + 62, force = (4200 / d2 + (d < min ? (min - d) * .5 : 0)) * alpha;
      dx /= d; dy /= d; a.vx -= dx * force; a.vy -= dy * force; b.vx += dx * force; b.vy += dy * force;
    }
  }
  edges.forEach(([a, b]) => {
    const na = nodes[a], nb = nodes[b], dx = nb.x - na.x, dy = nb.y - na.y, d = Math.hypot(dx, dy) || 1;
    const rest = na.group === nb.group ? 115 : 190, force = (d - rest) * .02 * alpha;
    na.vx += dx / d * force; na.vy += dy / d * force; nb.vx -= dx / d * force; nb.vy -= dy / d * force;
  });
  nodes.forEach((node, i) => {
    const [ax, ay] = anchors[node.group];
    node.vx += (ax - node.x) * .012 * alpha; node.vy += (ay - node.y) * .012 * alpha;
    if (drag && drag.i === i) return;
    node.vx *= .82; node.vy *= .82; node.x += node.vx; node.y += node.vy;
    node.x = Math.max(40, Math.min(W - 40, node.x)); node.y = Math.max(40, Math.min(H - 85, node.y));
  });
  heat = Math.max(drag ? .4 : 0, heat * .992);
}

function curve(a, b) {
  const dx = b.x - a.x, dy = b.y - a.y;
  return {x0: a.x, y0: a.y, cx: (a.x + b.x) / 2 - dy * .14, cy: (a.y + b.y) / 2 + dx * .14, x1: b.x, y1: b.y};
}

function render(time = 0) {
  nodeEls.forEach((g, i) => g.setAttribute('transform', `translate(${nodes[i].x.toFixed(1)},${nodes[i].y.toFixed(1)})`));
  edges.forEach(([a, b], i) => {
    const c = curve(nodes[a], nodes[b]);
    edgeEls[i].path.setAttribute('d', `M${c.x0},${c.y0} Q${c.cx},${c.cy} ${c.x1},${c.y1}`);
    Object.entries({x1: c.x0, y1: c.y0, x2: c.x1, y2: c.y1}).forEach(([key, value]) => edgeEls[i].gradient.setAttribute(key, value));
    // Sparks travel from caller to callee to suggest the direction of each flow.
    const t = ((time / 2200) + i * .137) % 1, u = 1 - t;
    sparks[i].setAttribute('cx', u * u * c.x0 + 2 * u * t * c.cx + t * t * c.x1);
    sparks[i].setAttribute('cy', u * u * c.y0 + 2 * u * t * c.cy + t * t * c.y1);
  });
  scene.setAttribute('transform', `translate(${view.x},${view.y}) scale(${view.k})`);
}

function frame(time) { if (heat > .002 || drag) tick(); render(time); requestAnimationFrame(frame); }

function applyHighlight() {
  const neighbors = new Set(selected < 0 ? [] : edges.filter(edge => edge.includes(selected)).flat());
  const visible = i => selected >= 0 ? neighbors.has(i) || i === selected : !filter || nodes[i].group === filter;
  nodeEls.forEach((g, i) => {
    g.classList.toggle('selected', i === selected);
    g.classList.toggle('connected', selected >= 0 && i !== selected && neighbors.has(i));
    g.classList.toggle('muted', !visible(i));
    g.setAttribute('aria-pressed', String(i === selected));
  });
  edges.forEach((edge, i) => {
    const on = selected >= 0 ? edge.includes(selected) : !filter || edge.every(n => nodes[n].group === filter);
    edgeEls[i].path.classList.toggle('active', selected >= 0 && on);
    edgeEls[i].path.classList.toggle('muted', !on);
    sparks[i].classList.toggle('muted', !on);
  });
}

function select(i) {
  selected = i; applyHighlight();
  if (i < 0) { detail.innerHTML = '<div class="badge">?</div><p>Seleziona un nodo per vederne ruolo e collegamenti. I nomi delle fonti sono sostituiti da codici anonimi.</p>'; return; }
  const node = nodes[i], color = groups[node.group].color;
  const out = edges.filter(([a]) => a === i).map(([, b]) => b), inc = edges.filter(([, b]) => b === i).map(([a]) => a);
  detail.style.setProperty('--c', color);
  detail.innerHTML = `<div class="badge">${String(i + 1).padStart(2, '0')}</div><div><h2></h2><div class="chips"></div></div>`;
  detail.querySelector('h2').append(node.role, Object.assign(document.createElement('small'), {textContent: `${groups[node.group].name} · ${inc.length} in entrata · ${out.length} in uscita · fonte oscurata`}));
  const chips = detail.querySelector('.chips');
  [...inc.map(n => [n, '←']), ...out.map(n => [n, '→'])].forEach(([n, arrow]) => {
    const chip = document.createElement('button');
    chip.type = 'button'; chip.style.setProperty('--c', groups[nodes[n].group].color);
    chip.textContent = `${arrow} ${nodes[n].role}`;
    chip.addEventListener('click', () => { select(n); nodeEls[n].focus(); });
    chips.appendChild(chip);
  });
}

const legend = document.getElementById('legend');
const legendButtons = Object.entries(groups).map(([key, group]) => {
  const button = document.createElement('button');
  button.type = 'button'; button.style.setProperty('--c', group.color); button.setAttribute('aria-pressed', 'false');
  button.innerHTML = '<i></i>'; button.append(group.name);
  button.addEventListener('click', () => {
    filter = filter === key ? null : key;
    legendButtons.forEach(b => b.setAttribute('aria-pressed', String(b === button && filter === key)));
    select(-1);
  });
  legend.appendChild(button);
  return button;
});

function zoomAt(factor, px = CX, py = CY) {
  const k = Math.max(.5, Math.min(3, view.k * factor)), ratio = k / view.k;
  view = {k, x: px - (px - view.x) * ratio, y: py - (py - view.y) * ratio};
  if (reduceMotion) render();
}
function svgPoint(event) { return new DOMPoint(event.clientX, event.clientY).matrixTransform(svg.getScreenCTM().inverse()); }
svg.addEventListener('wheel', event => { event.preventDefault(); const p = svgPoint(event); zoomAt(event.deltaY < 0 ? 1.12 : 1 / 1.12, p.x, p.y); }, {passive: false});
svg.addEventListener('pointerdown', event => { const p = svgPoint(event); pan = {x: p.x - view.x, y: p.y - view.y, moved: false}; svg.setPointerCapture(event.pointerId); svg.classList.add('panning'); });
svg.addEventListener('pointermove', event => { if (!pan) return; const p = svgPoint(event); view.x = p.x - pan.x; view.y = p.y - pan.y; pan.moved = true; if (reduceMotion) render(); });
svg.addEventListener('pointerup', () => { if (pan && !pan.moved) select(-1); pan = null; svg.classList.remove('panning'); });
svg.addEventListener('pointercancel', () => { pan = null; svg.classList.remove('panning'); });

document.getElementById('zoom-in').addEventListener('click', () => zoomAt(1.2));
document.getElementById('zoom-out').addEventListener('click', () => zoomAt(1 / 1.2));
document.getElementById('reset').addEventListener('click', () => {
  view = {x: 0, y: 0, k: 1}; filter = null; legendButtons.forEach(b => b.setAttribute('aria-pressed', 'false'));
  placeNodes(); select(-1); if (reduceMotion) settle();
});
const stage = document.querySelector('.stage'), fullscreen = document.getElementById('fullscreen');
if (!stage.requestFullscreen) fullscreen.hidden = true;
fullscreen.addEventListener('click', () => document.fullscreenElement ? document.exitFullscreen() : stage.requestFullscreen().catch(() => {}));
document.addEventListener('fullscreenchange', () => { svg.style.height = document.fullscreenElement ? '100vh' : ''; });

function settle() { for (let n = 0; n < 600; n++) tick(); heat = 0; render(); }
document.getElementById('stat-nodes').textContent = nodes.length;
document.getElementById('stat-edges').textContent = edges.length;
document.getElementById('stat-groups').textContent = Object.keys(groups).length;
placeNodes();
if (reduceMotion) settle(); else { for (let n = 0; n < 120; n++) tick(); requestAnimationFrame(frame); }
