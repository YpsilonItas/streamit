// Anonymous architecture only: no source names, domains or runtime URLs.
'use strict';
const roles = ['Interfaccia', 'Catalogo film', 'Catalogo serie', 'Ricerca', 'Immagini e metadati', 'Riproduzione video', 'Sezione TV', 'Guida programmi', 'Lista principale', 'Lista alternativa', 'Motore TV', 'Aggiornamenti', 'Pubblicazione', 'Preferiti locali', 'Gestione audio'];
const edges = [[0,1],[0,2],[0,3],[0,5],[0,6],[0,11],[1,4],[2,4],[3,4],[1,5],[2,5],[3,5],[6,7],[6,8],[6,9],[6,10],[6,13],[8,10],[11,12],[5,14],[0,14]];
const nodes = roles.map((role, i) => ({role, label:`•••• ${String(i+1).padStart(2,'0')}`, x:i ? 450+205*Math.cos((i-1)*2*Math.PI/(roles.length-1)) : 450, y:i ? 250+180*Math.sin((i-1)*2*Math.PI/(roles.length-1)) : 250}));
const svg = document.getElementById('graph'), scene = document.getElementById('scene'), detail = document.getElementById('detail');
const ns = 'http://www.w3.org/2000/svg';
function element(tag, attrs, parent) { const el=document.createElementNS(ns,tag); Object.entries(attrs).forEach(([key,value])=>el.setAttribute(key,value));parent.appendChild(el);return el; }
const lines=edges.map(([a,b])=>element('line',{},scene));
let selected=-1, zoom=1, drag=null;
const groups=nodes.map((node,i)=>{
  const g=element('g',{class:'node',tabindex:'0',role:'button','aria-label':`Nodo anonimo ${i+1}: ${node.role}`,'aria-pressed':'false'},scene);
  element('circle',{r:i ? 9 : 15},g);
  const text=element('text',{x:0,y:29,'text-anchor':'middle'},g);text.textContent=node.label;
  g.addEventListener('click',()=>select(i));
  g.addEventListener('keydown',event=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();select(i);}});
  g.addEventListener('pointerdown',event=>{event.preventDefault();drag=i;g.setPointerCapture(event.pointerId);});
  g.addEventListener('pointermove',event=>{if(drag!==i)return;const point=new DOMPoint(event.clientX,event.clientY).matrixTransform(scene.getScreenCTM().inverse());node.x=Math.max(35,Math.min(865,point.x));node.y=Math.max(35,Math.min(455,point.y));render();});
  g.addEventListener('pointerup',()=>{drag=null;});g.addEventListener('pointercancel',()=>{drag=null;});
  return g;
});
function render(){groups.forEach((g,i)=>g.setAttribute('transform',`translate(${nodes[i].x},${nodes[i].y})`));edges.forEach(([a,b],i)=>{Object.entries({x1:nodes[a].x,y1:nodes[a].y,x2:nodes[b].x,y2:nodes[b].y}).forEach(([key,value])=>lines[i].setAttribute(key,value));});scene.setAttribute('transform',`translate(${450*(1-zoom)},${250*(1-zoom)}) scale(${zoom})`);}
function select(i){selected=i;const neighbors=new Set(edges.filter(edge=>edge.includes(i)).flat());groups.forEach((g,j)=>{g.classList.toggle('selected',j===i);g.classList.toggle('connected',j!==i&&neighbors.has(j));g.classList.toggle('muted',j!==i&&!neighbors.has(j));g.setAttribute('aria-pressed',String(j===i));});lines.forEach((line,j)=>{line.classList.toggle('active',edges[j].includes(i));line.classList.toggle('muted',!edges[j].includes(i));});detail.textContent=`Nodo ${i+1} · ${nodes[i].role} · ${edges.filter(edge=>edge.includes(i)).length} collegamenti. Nome della fonte oscurato.`;}
document.getElementById('zoom-in').addEventListener('click',()=>{zoom=Math.min(2,zoom+.15);render();});
document.getElementById('zoom-out').addEventListener('click',()=>{zoom=Math.max(.6,zoom-.15);render();});
document.getElementById('reset').addEventListener('click',()=>{selected=-1;zoom=1;nodes.forEach((node,i)=>{node.x=i ? 450+205*Math.cos((i-1)*2*Math.PI/(nodes.length-1)) : 450;node.y=i ? 250+180*Math.sin((i-1)*2*Math.PI/(nodes.length-1)) : 250;});groups.forEach(g=>{g.setAttribute('class','node');g.setAttribute('aria-pressed','false');});lines.forEach(line=>line.setAttribute('class',''));detail.textContent='Seleziona un nodo. I nomi sono sostituiti da codici anonimi.';render();});
render();
