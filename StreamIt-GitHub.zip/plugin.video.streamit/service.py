from resources.lib.audio import run

run()
