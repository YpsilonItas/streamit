"""Local password gate. Credentials never belong in the public package."""
import hashlib
import hmac
import os
import time
import xbmcaddon
import xbmcgui

SETTING = 'iptv_password_hash'
GRANT = 'streamit.iptv.access'


def encode_password(password):
    salt = os.urandom(16).hex()
    digest = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), bytes.fromhex(salt), 200000).hex()
    return salt + ':' + digest


def matches(password, stored):
    try:
        salt, digest = stored.split(':')
        actual = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), bytes.fromhex(salt), 200000).hex()
        return hmac.compare_digest(actual, digest)
    except (ValueError, TypeError):
        return False


def change_password():
    addon = xbmcaddon.Addon('plugin.video.streamit')
    if not addon.getSetting(SETTING):
        xbmcgui.Dialog().notification('StreamIt', 'Accesso riservato al creatore dell’addon.', time=4000)
        return False
    if not authorize(force=True):
        return False
    dialog = xbmcgui.Dialog()
    password = dialog.input('Nuova password IPTV alternativa', option=xbmcgui.ALPHANUM_HIDE_INPUT)
    if not password:
        return False
    confirmation = dialog.input('Conferma password', option=xbmcgui.ALPHANUM_HIDE_INPUT)
    if password != confirmation:
        dialog.notification('StreamIt', 'Le password non coincidono.', time=4000)
        return False
    addon.setSetting(SETTING, encode_password(password))
    xbmcgui.Window(10000).clearProperty(GRANT)
    dialog.notification('StreamIt', 'Password salvata.', time=3000)
    return True


def authorize(force=False):
    addon, window, dialog = xbmcaddon.Addon('plugin.video.streamit'), xbmcgui.Window(10000), xbmcgui.Dialog()
    stored = addon.getSetting(SETTING)
    if not stored:
        dialog.notification('StreamIt', 'Accesso riservato al creatore dell’addon.', time=4000)
        return False
    try:
        if not force and float(window.getProperty(GRANT) or '0') > time.time():
            return True
    except ValueError:
        pass
    password = dialog.input('Password IPTV alternativa', option=xbmcgui.ALPHANUM_HIDE_INPUT)
    if not password:
        return False
    if not matches(password, stored):
        dialog.notification('StreamIt', 'Password errata.', time=3000)
        return False
    window.setProperty(GRANT, str(time.time() + 300))
    return True
