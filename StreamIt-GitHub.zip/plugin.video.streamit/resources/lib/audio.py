"""Saved audio preference with verified, bounded startup selection."""
import json
import re
import time
import xbmc
import xbmcgui
import xbmcaddon

PENDING = 'streamit.pending.italian_audio'
LANGUAGES = [
    ('it', 'Italiano', 'Italian', ('it', 'ita'), ('italiano', 'italian', 'ita')),
]


def selected_track(streams, key):
    language_info = next((row for row in LANGUAGES if row[0] == key), LANGUAGES[0])
    named = []
    for stream in streams:
        language = str(stream.get('language', '')).strip().lower().replace('_', '-')
        name = str(stream.get('name', '')).casefold()
        if language.split('-')[0] in language_info[3] + language_info[4]:
            return stream['index']
        # An explicit conflicting language is more reliable than a display name.
        known = language.split('-')[0] in ('en', 'eng', 'english', 'inglese') or any(language.split('-')[0] in row[3] + row[4] for row in LANGUAGES)
        if not known and any(re.search(r'\b' + re.escape(word) + r'\b', name)
                             for word in language_info[3] + language_info[4]):
            named.append(stream['index'])
    return named[0] if named else None


def prepare(stream_url, title=''):
    window = xbmcgui.Window(10000)
    addon = xbmcaddon.Addon('plugin.video.streamit')
    key = 'it'
    language_info = next((row for row in LANGUAGES if row[0] == key), LANGUAGES[0])
    for setting, value in [('locale.audiolanguage', language_info[2]), ('videoplayer.preferdefaultflag', False)]:
        try:
            result = json.loads(xbmc.executeJSONRPC(json.dumps({
                'jsonrpc': '2.0', 'id': 1, 'method': 'Settings.SetSettingValue',
                'params': {'setting': setting, 'value': value}})))
            if result.get('result') is not True:
                xbmc.log('[StreamIt] Audio preference rejected: ' + setting, xbmc.LOGWARNING)
        except (ValueError, RuntimeError):
            xbmc.log('[StreamIt] Cannot set audio preference: ' + setting, xbmc.LOGWARNING)
    window.setProperty(PENDING, json.dumps({
        'url': stream_url.split('|')[0], 'title': title, 'language': key,
        'expires': time.time() + 90}))


class AudioPlayer(xbmc.Player):
    def __init__(self):
        super().__init__()
        self.started = False

    def onAVStarted(self):
        self.started = True

    def onPlayBackStopped(self):
        self.started = False

    def onPlayBackEnded(self):
        self.started = False


def run():
    from resources.lib.updates import RepositoryUpdates
    monitor, player, window = xbmc.Monitor(), AudioPlayer(), xbmcgui.Window(10000)
    updates = RepositoryUpdates()
    active, started, stable, attempted = '', 0, None, None
    while not monitor.abortRequested():
        updates.tick(player.isPlaying())
        raw = window.getProperty(PENDING)
        if raw:
            try:
                pending = json.loads(raw)
                if time.time() > pending['expires']:
                    if window.getProperty(PENDING) == raw:
                        window.clearProperty(PENDING)
                elif player.isPlayingVideo() and (
                    player.getPlayingFile().split('|')[0] == pending['url'] or
                    (player.started and pending.get('title') and xbmc.getInfoLabel('VideoPlayer.Title') == pending['title'])):
                    if active != raw:
                        active, started = raw, time.time()
                        stable, attempted = None, None
                    result = json.loads(xbmc.executeJSONRPC(json.dumps({
                        'jsonrpc': '2.0', 'id': 1, 'method': 'Player.GetProperties',
                        'params': {'playerid': 1, 'properties': ['audiostreams', 'currentaudiostream']}})))
                    streams = result.get('result', {}).get('audiostreams', [])
                    if not streams:
                        streams = [{'index': i, 'name': name, 'language': name}
                                   for i, name in enumerate(player.getAvailableAudioStreams())]
                    track = selected_track(streams, pending.get('language', 'it'))
                    current = result.get('result', {}).get('currentaudiostream', {}).get('index')
                    now = time.time()
                    if track is not None and current == track:
                        if stable is None:
                            stable = now
                    else:
                        stable = None
                        if track is not None and (attempted is None or now - attempted >= 1):
                            player.setAudioStream(track)
                            attempted = now
                    # Wait for stable confirmation; stop before normal manual track changes.
                    confirmed = stable is not None and now - stable >= 2
                    if confirmed or now - started > 20:
                        if not confirmed:
                            label = 'italiana'
                            message = ('Traccia ' + label + ' non disponibile o non identificata.'
                                       if track is None else 'Cambio audio non confermato: verifica le tracce del lettore.')
                            xbmcgui.Dialog().notification('StreamIt', message, time=5000)
                        if window.getProperty(PENDING) == raw:
                            window.clearProperty(PENDING)
                        player.started = False
            except (ValueError, KeyError, TypeError, RuntimeError):
                pass  # The player can disappear between the checks during stop/skip.
        if monitor.waitForAbort(0.25):
            break
