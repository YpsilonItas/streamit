"""Single fixed video catalogue."""
DEFAULT_SITE = "https://vixsrc.to"

def get_sources(addon=None):
    return [{"name": "VixSrc", "url": DEFAULT_SITE}]
