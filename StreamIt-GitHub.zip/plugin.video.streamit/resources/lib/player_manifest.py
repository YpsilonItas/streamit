"""Read the public HLS configuration published by a video player."""
import json
import re
from urllib.parse import urlencode, urlparse, parse_qsl, urlunparse

def embed(soup):
    return None

def playlist(soup):
    """Legge i parametri pubblicati dal player senza eseguire JavaScript."""
    for script in soup.select('script:not([src])'):
        text = script.get_text()
        match = re.search(r'window\.masterPlaylist\s*=\s*(.*?)(?:window\.|$)', text, re.S)
        if not match:
            continue
        block = match.group(1)
        values = dict(re.findall(r"['\"]?(url|token|expires|asn)['\"]?\s*:\s*['\"]([^'\"]*)['\"]", block))
        for key, value in re.findall(r"['\"]?(expires|asn)['\"]?\s*:\s*(\d+)\b", block):
            values.setdefault(key, value)
        url = values.pop('url', '').replace('\\/', '/')
        server_match = re.search(r'window\.streams\s*=\s*(\[.*?\])\s*;', text, re.S)
        if server_match:
            try:
                servers = json.loads(server_match.group(1))
                active = next((server for server in servers if server.get('active') and server.get('url')), None)
                if active:
                    url = active['url']
            except (ValueError, TypeError):
                pass
        if not url:
            continue
        parsed = urlparse(url)
        if parsed.scheme not in ('http', 'https'):
            continue
        params = dict(parse_qsl(parsed.query))
        params.update({k: v for k, v in values.items() if v})
        player_query = dict(parse_qsl(urlparse(getattr(soup, '_streamit_url', '') or '').query))
        if player_query.get('canPlayFHD'):
            params['h'] = '1'
        return urlunparse(parsed._replace(query=urlencode(params)))
    return None
