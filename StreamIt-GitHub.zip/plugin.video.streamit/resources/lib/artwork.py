"""Select real high-resolution images without inventing remote URLs."""
from urllib.parse import urljoin, urlparse


def image_url(value, base):
    if not value or not str(value).strip():
        return ''
    url = urljoin(base, str(value).strip())
    parsed = urlparse(url)
    if parsed.scheme not in ('http', 'https') or parsed.path.lower().endswith(('.avif', '.svg', '.heic', '.heif')):
        return ''
    return url


def best_image(image, base):
    if image is None:
        return ''
    def usable(value):
        return image_url(value, base)
    for key in ('data-original', 'data-full', 'data-large'):
        value = usable(image.get(key))
        if image.get(key) and value:
            return value
    candidates = []
    nodes = [image]
    if image.parent and image.parent.name == 'picture':
        nodes += image.parent.select('source')
    for node in nodes:
        if node.get('type') in ('image/avif', 'image/svg+xml', 'image/heic', 'image/heif'):
            continue
        for entry in (node.get('data-srcset') or node.get('srcset') or '').split(','):
            parts = entry.strip().rsplit(None, 1)
            if len(parts) != 2 or parts[1][-1:] not in ('w', 'x'):
                continue
            try:
                size = float(parts[1][:-1])
            except ValueError:
                continue
            value = usable(parts[0])
            if value:
                candidates.append((parts[1][-1] == 'w', size, value))
    if candidates:
        return max(candidates, key=lambda item: (item[0], item[1]))[2]
    for key in ('data-lazy-src', 'data-src', 'src'):
        value = usable(image.get(key))
        if image.get(key) and value:
            return value
    return ''
