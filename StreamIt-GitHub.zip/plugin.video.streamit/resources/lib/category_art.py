"""Icone locali per navigazione e generi, senza richieste di rete."""
from urllib.parse import urlparse, parse_qs
import unicodedata

ACTION_ICONS = {'iptv': 'tv', 'play_iptv': 'tv', 'movies': 'film', 'series': 'tv', 'search': 'search',
    'search_results': 'search', 'genres': 'genres', 'sources': 'sites', 'home': 'sites',
    'manage': 'settings', 'settings': 'settings', 'refresh_all': 'refresh',
    'add_source': 'add', 'edit_source': 'edit', 'detect_source': 'check',
    'seasons': 'season', 'episodes': 'season', 'play': 'episode'}
GENRE_ICONS = [
    (('fantascienza', 'science fiction', 'sci-fi'), 'scifi'),
    (('animazione', 'animation', 'anime'), 'animation'),
    (('avventura', 'adventure'), 'adventure'),
    (('azione', 'action'), 'action'),
    (('commedia', 'comico', 'comedy', 'grottesco'), 'comedy'),
    (('dramma', 'drama'), 'drama'),
    (('romance', 'sentimentale', 'erotico'), 'romance'),
    (('horror',), 'horror'), (('fantasy', 'fantastico'), 'fantasy'),
    (('music',), 'music'), (('storic', 'history', 'biograf'), 'history'),
    (('guerra', 'war'), 'war'), (('crime', 'poliziesco', 'gangster', 'noir'), 'crime'),
    (('document',), 'documentary'), (('western',), 'western'),
    (('thriller', 'mister', 'mystery', 'giallo'), 'mystery')]


def choose_icon(title, url):
    if title.strip().casefold() == 'avanti':
        return 'next'
    action = parse_qs(urlparse(url).query).get('action', [''])[0]
    if action == 'genre_content':
        title = unicodedata.normalize('NFKD', title).encode('ascii', 'ignore').decode().casefold()
        for words, icon in GENRE_ICONS:
            if any(word in title for word in words):
                return icon
        return 'genres'
    return ACTION_ICONS.get(action, 'genres')
